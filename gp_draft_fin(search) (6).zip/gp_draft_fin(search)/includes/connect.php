<!-- code to connect to sql database, do not change!!!  -->

<?php

$con=mysqli_connect('localhost','rm1469_temp','z1@*Cb[kJe^d','rm1469_CI536');
if(!$con){
    die(mysqli_error($con));
    
}



?>